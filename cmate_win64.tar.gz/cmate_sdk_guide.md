# CMate Software Development Kit Guide

## Description

CMate can be used in a custom software using the CMate static library.

## Compatibility

The static library is compatible with the followng toolchains.

- On Windows

  - The `libcmate.a` is compatible with GCC and LLVM-based toolchains.
  - The `cmate.lib` is compatible with Rust and MSVC toolchains.

- On Linux:

  - The `libcmate.a` is compatible with Rust, GCC and LLVM-based toolchains.

## Toolchain versions

The static library is built using the following toolchain versions.

### Rust toolchain

```bash
$ rustc --version --verbose
rustc 1.99.1 (58cf8f9c3 2026-10-13)
binary: rustc
commit-hash: 58cf8f9c35b355199727627d07ae34a4e2846d67
commit-date: 2026-10-13
host: x86_64-pc-windows-msvc
release: 1.99.1
LLVM version: 23.1.1
```

### GCC toolchain

```bash
$ gcc -v
Using built-in specs.
COLLECT_GCC=D:\a\_temp\mingw64\mingw64\bin\gcc.exe
COLLECT_LTO_WRAPPER=D:/a/_temp/mingw64/mingw64/bin/../libexec/gcc/x86_64-w64-mingw32/16.2.0/lto-wrapper.exe
OFFLOAD_TARGET_NAMES=nvptx-none
Target: x86_64-w64-mingw32
Configured with: ../configure --prefix=/D/Temp/_/inst_gcc-16.2.0/share/gcc --build=x86_64-w64-mingw32 --host=x86_64-w64-mingw32 --enable-offload-targets=nvptx-none --with-pkgversion='MinGW-W64 x86_64-ucrt-posix-seh, built by Brecht Sanders, r3' --with-tune=generic --enable-checking=release --enable-threads=posix --disable-sjlj-exceptions --disable-libunwind-exceptions --disable-serial-configure --disable-bootstrap --enable-host-shared --enable-plugin --disable-default-ssp --disable-rpath --disable-libstdcxx-debug --disable-version-specific-runtime-libs --disable-symvers --enable-languages=c,c++,fortran,lto,objc,obj-c++ --disable-gold --disable-nls --disable-stage1-checking --disable-win32-registry --disable-multilib --enable-ld --enable-libquadmath --enable-libada --enable-libssp --enable-libstdcxx --enable-lto --enable-fully-dynamic-string --enable-libgomp --enable-graphite --enable-mingw-wildcard --enable-libstdcxx-time --enable-libstdcxx-pch --with-mpc=/d/Prog/winlibs_staging_ucrt/custombuilt64 --with-mpfr=/d/Prog/winlibs_staging_ucrt/custombuilt64 --with-gmp=/d/Prog/winlibs_staging_ucrt/custombuilt64 --with-isl=/d/Prog/winlibs_staging_ucrt/custombuilt64 --disable-libstdcxx-backtrace --enable-install-libiberty --enable-__cxa_atexit --without-included-gettext --with-diagnostics-color=auto --enable-clocale=generic --enable-libgdiagnostics --with-libiconv --with-system-zlib --with-build-sysroot=/D/Temp/_/gcc-16.2.0/build_mingw/mingw-w64 CFLAGS='-I/d/Prog/winlibs_staging_ucrt/custombuilt64/include/libdl-win32   -march=nocona -msahf -mtune=generic -O2 -Wno-error=format' CXXFLAGS='-Wno-int-conversion  -march=nocona -msahf -mtune=generic -O2' LDFLAGS='-pthread -Wl,--no-insert-timestamp -Wl,--dynamicbase -Wl,--high-entropy-va -Wl,--nxcompat -Wl,--tsaware' LD=/d/Prog/winlibs_staging_ucrt/custombuilt64/share/binutils/bin/ld.exe
Thread model: posix
Supported LTO compression algorithms: zlib zstd
gcc version 16.2.0 (MinGW-W64 x86_64-ucrt-posix-seh, built by Brecht Sanders, r3) 
```

## CMate Rust API

```rust
unsafe extern "Rust" {
    ///
    /// Runs the given project using the `cmate` runtime and returns its output.
    ///
    /// This is exposed as an `extern "Rust"` entry point so it can be called
    /// across a crate/dylib boundary (e.g. from a plugin host or dynamically
    /// loaded module) while still using Rust's native ABI and types.
    ///
    /// # Arguments
    ///
    /// * `argv` - The argument list to pass through to the project's entry
    ///   point, analogous to `std::env::args()` but without the program name.
    ///
    /// # Returns
    ///
    /// * `Ok(String)` - The captured output produced by running the project
    ///   (e.g. combined stdout, or a result summary), on success.
    /// * `Err(String)` - A human-readable error message describing why the
    ///   project could not be run (e.g. project not found, invalid arguments,
    ///   or a runtime failure during execution).
    ///
    /// # Errors
    ///
    ///   See the `Returns` section for the description of errors.
    ///
    /// # Examples
    ///
    /// ```
    /// unsafe extern "Rust" {
    ///     pub unsafe fn cmate_rust_run(argv: &[&str]) -> Result<String, String>;
    /// }
    ///
    /// fn main() {
    ///     let result = unsafe { cmate_rust_run(&["--help"]) };
    ///     match result {
    ///         Ok(info) => println!("CMate success. Info:\n\n{info}\n"),
    ///         Err(error) => println!("CMate error. Error:\n\n{error}\n"),
    ///     }
    /// }
    /// ```
    ///
    /// # Safety
    ///
    /// This function is not marked `unsafe` and does not take raw pointers,
    /// but because it is declared `extern "Rust"`, it must only be called
    /// from code compiled with a compatible Rust compiler/ABI version — it
    /// is **not** safe to call across an FFI boundary from C or another
    /// language, or between binaries built with mismatched `rustc` versions.
    ///
    pub unsafe fn cmate_rust_run(argv: &[&str]) -> Result<String, String>;
}
```

## CMate C API

```c
///
/// Runs the given project using the `cmate` runtime and returns its output,
/// writing the result into a caller-provided buffer.
///
/// This is the C-ABI counterpart to [`cmate_rust_run`], intended to be
/// called from non-Rust code (or across a `dylib`/FFI boundary) using
/// C-style null-terminated strings and a caller-owned output buffer
/// instead of Rust's `String`/`Result` types.
///
/// # Arguments
///
/// * `argv` - Pointer to a null-terminated array of null-terminated C
///   strings, analogous to a C `argv`. The array itself must be
///   terminated by a null pointer, and each element must point to a
///   valid null-terminated string.
/// * `resultbuf` - Pointer to a caller-allocated buffer that will receive
///   the null-terminated result (success output or error message) on
///   return.
/// * `resultcap` - The capacity, in bytes, of `resultbuf`. The function
///   will not write more than this many bytes, including the terminating
///   null byte.
///
/// # Returns
///
/// An `isize` status code:
/// * A zero value indicates success.
/// * A non-zero value indicates failure.
///
/// # Examples
///
/// ```
/// /*
///  * Do not forget to also link the following libraries to you application:
///  * Windows: `ws2_32`, `ntdll`, `userenv`
///  * Linux: `m`
///  */
/// #include <stdio.h>
/// #include <stdint.h>
/// extern intptr_t cmate_c_run(const char * const * const argv, char * const resultbuf, const uintptr_t resultcap);
/// int main(void) {
///     intptr_t result;
///     char message[1024U];
///     const char * const argv[] = { "--help", NULL };
///     result = cmate_c_run(argv, message, sizeof(message));
///     if (result == 0) { printf("CMate success. Info:\n\n%s\n", message); }
///     else             { printf("CMate error. Error:\n\n%s\n", message); }
///     return 0;
/// }
/// ```
///
/// # Panics
///
/// The function panics if the pointers are null.
///
/// # Safety
///
/// Do not pass null-pointers to the function. In addition, callers must
/// ensure that:
///
/// * `argv` points to a valid, null-terminated array of valid,
///   null-terminated C strings, all of which remain valid for the
///   duration of the call.
/// * `resultbuf` points to a writable buffer of at least `resultcap`
///   bytes, valid for the duration of the call.
/// * `resultbuf` and `resultcap` accurately describe the same
///   allocation — passing a `resultcap` larger than the actual buffer
///   is undefined behavior.
/// * The memory regions referenced by `argv`, and `resultbuf`
///   do not overlap in a way that violates Rust's aliasing rules.
///
extern intptr_t cmate_c_run(const char * const * const argv, char * const resultbuf, const uintptr_t resultcap);
```

## CMate Rust SDK example

```rust
unsafe extern "Rust" {
    pub unsafe fn cmate_rust_run(argv: &[&str]) -> Result<String, String>;
}
fn main() {
    let result = unsafe { cmate_rust_run(&["--help"]) };
    match result {
        Ok(info) => println!("CMate success. Info:\n\n{info}\n"),
        Err(error) => println!("CMate error. Error:\n\n{error}\n"),
    }
}
```

## CMate C SDK example

```c
/*
 * Do not forget to also link the following libraries to you application:
 * Windows: `ws2_32`, `ntdll`, `userenv`
 * Linux: `m`
 */
#include <stdio.h>
#include <stdint.h>
extern intptr_t cmate_c_run(const char * const * const argv, char * const resultbuf, const uintptr_t resultcap);
int main(void) {
    intptr_t result;
    char message[1024U];
    const char * const argv[] = { "--help", NULL };
    result = cmate_c_run(argv, message, sizeof(message));
    if (result == 0) { printf("CMate success. Info:\n\n%s\n", message); }
    else             { printf("CMate error. Error:\n\n%s\n", message); }
    return 0;
}
```
