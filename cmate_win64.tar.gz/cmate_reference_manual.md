# CMate Reference Manual

## Configuration file of a CMate project

The project configuration file of CMate is one and only one [rhai](https://rhai.rs/book/about/features.html) script file. This rhai script file serves the very same purpose as a CMakeLists.txt file for the CMake build system, or a meson.build file for the Meson build system. It contains variables that are necessary for the building of the C/C++ project.

### The anatomy of a CMate project configuration file

The rhai script language uses a Rust-like syntax with dynamic typing.

The rhai script file can contain multiple build configurations. A build configuration variable can be created by the following code.

```rust
let build_config = CMate_BuildConfig_new();
```

This code creates a variable named `build_config` which is a structure with multiple fields. See below for the explanation of all build configuration structure fields.

The rhai script file shall always end with the following code.

```rust
CMate_Project("ExampleProject", [build_config])
```

The first parameter of the `CMate_Project()` function is the descriptive name of the project.
The second parameter of the `CMate_Project()` function is the array of build configuration variables which are created by the `CMate_BuildConfig_new()` function.

### Build configuration structure fields

#### General information

- Every path is relative to the rhai script file unless stated otherwise.
- Absolute paths can be used, but they are converted to relative paths internally, so absolute paths across different drives will not work on Windows. That is why relative paths should be used instead.
- Toolchain specific flags shall only be used with the following fields:
  - target_flags
  - compiler_flags
  - linker_flags
  - ext_list_creator_flags

#### build_name

- Description: The name of the build configuration. Every build configuration shall have a unique name. The build files and the artifact files are placed into a directory having this name next to the rhai script file.
- Type: String
- Mandatory Field: Yes
- Examples: `"Debug"`, `"Release"`

#### build_type

- Description: The type of the build configuration. Whether to build an executable file or build a static library file.
- Type: String
- Mandatory Field: Yes
- Accepted Values: "Executable", "StaticLib"
- Examples: `"Executable"`, `"StaticLib"`

#### artifact_base_name

- Description: The base name of the artifact file. The artifact file is the final product of the build, an executable file or a static library file.
- Type: String
- Mandatory Field: Yes
- Examples: `"myexecutable"`, `"mylib"`

#### artifact_extension

- Description: The extension of the artifact file. The artifact file is the final product of the build, an executable file or a static library file. This field is only taken into account if the build type is executable. The artifact file will have a `lib` prefix and a `.a` extension if the build type is static library.
- Type: String
- Mandatory Field: Yes
- Examples: `".exe"`, `".elf"`, `""`

#### install_dir

- Description: The directory where the artifact file will be copied when CMate executes the install target. The directory will be created if it does not exist.
- Type: String
- Mandatory Field: Yes
- Examples: `"Install"`

#### parallel_build_jobs

- Description: The number of parallel build jobs ninja or make will use to execute the build process.
- Type: Integer
- Mandatory Field: No, default value: number of processor cores
- Examples: `8`

#### toolchain_prefix

- Description: A string that will act as a prefix when invoking toolchain executables (compiler, linker, archiver, etc.). The toolchain executable is invoked prefixed by this value without any spaces or additional characters.
- Type: String
- Mandatory Field: Yes
- Examples: `"arm-none-eabi-"`, `""`

#### compiler_path, linker_path, archiver_path, img_file_creator_path, ext_list_creator_path, size_printer_path

- Description: The toolchain executables.
- Type: String
- Mandatory Field: Yes
- Example for Desktop GCC (in order): `"gcc"`, `"gcc"`, `"ar"`, `"objcopy"`, `"objdump"`, `"size"`
- Example for ARM32 GCC (in order): `"arm-none-eabi-gcc"`, `"arm-none-eabi-gcc"`, `"arm-none-eabi-ar"`, `"arm-none-eabi-objcopy"`, `"arm-none-eabi-objdump"`, `"arm-none-eabi-size"`
- Example for CLANG (in order): `"clang"`, `"clang"`, `"llvm-ar"`, `"llvm-objcopy"`, `"llvm-objdump"`, `"llvm-size"`

#### pre_build_steps, post_build_steps

- Description: Commands to execute before or after the build. The post-build step is only executed if the build process succeeds. The commands are executed as subprocesses. Multiple commands can be separated with the `;` character.
- Type: Array of Strings
- Mandatory Field: Yes
- Example for running the built application as post-build step: `["./Debug/program.exe"]`
- Example for running a Windows shell command as post-build step: `["cmd", "/c", "echo Build Finished"]`
- Example for running a Linux shell command as post-build step: `["sh", "-c", "echo Build Finished"]`
- Example for running multiple post-build steps: `["post", "build", "step", "1", ";", "post", "build", "step", "2", ";", "post", "build", "step", "3"]`

#### dependency_build_configs

- Description: The names of the build configurations that are the dependencies of the current build configuration. Dependency build configurations will be built prior to the current build configuration. Multiple build configurations can be chained with this option. Can be useful for example when an executable file depends on a static library file.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["StaticLib"]`

#### dependency_project_paths

- Description: Currently not used. Reserved for future use.

#### linker_scripts

- Description: The linker scripts to use when linking the object files to an executable file.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["memregions.ld", "linker.ld"]`

#### linker_search_dirs

- Description: Additional directories where the linker will search for additional libraries.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["StaticLib"]`

#### linker_additional_libs

- Description: Additional libraries to link to the executable. Do not include the `lib` prefix and `.a` extension when specifying additional libraries, those are added automatically by the toolchain. So, if `libmylib.a` is a static library that should be linked to the executable, specify `mylib` here.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["mylib"]`

#### include_dirs

- Description: Include directories. The Unix [glob](https://en.wikipedia.org/wiki/Glob_(programming)) syntax can be used to specify paths with wildcards.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["inc"]`
- Example with glob syntax that lists all directories in the current directory non-recursively: `["*"]`
- Example with glob syntax that lists all directories in the current directory recursively: `["**"]`

#### include_files

- Description: Header files that will be pre-included to the beginning of all source files. The Unix [glob](https://en.wikipedia.org/wiki/Glob_(programming)) syntax can be used to specify paths with wildcards.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["mypreincludedheaderfile.h"]`
- Example with glob syntax that lists all header files in the current directory non-recursively: `["*.h", "*.hpp"]`
- Example with glob syntax that lists all header files in the current directory recursively: `["**/*.h", "**/*.hpp"]`

#### source_files

- Description: Source files. The Unix [glob](https://en.wikipedia.org/wiki/Glob_(programming)) syntax can be used to specify paths with wildcards.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["src/lib.c", "src/main.c"]`
- Example with glob syntax that lists all source files in the current directory non-recursively: `["*.c", "*.cpp"]`
- Example with glob syntax that lists all source files in the current directory recursively: `["**/*.c", "**/*.cpp"]`

#### defined_preprocessor_macros

- Description: Defined preprocessor macros.
- Type: Array of Strings
- Mandatory Field: Yes
- Example without value: `["MYMACRO"]`
- Example with integer value: `["MYMACROWITHINTVALUE=42"]`
- Example with string value: `["MYMACROWITHSTRINGVALUE='Hello\r\nWorld!'"]`

#### undefined_preprocessor_macros

- Description: Undefined preprocessor macros.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["MYMACRO"]`

#### target_flags

- Description: Toolchain-specific target-specific flags. These flags will be passed both to the compiler and linker.
- Type: Array of Strings
- Mandatory Field: Yes
- Example for a desktop target: `["-march=x86-64"]`
- Example for an ARM-Cortex-M4 target: `["-mcpu=cortex-m4", "-mthumb", "-mfloat-abi=hard", "-mfpu=fpv4-sp-d16"]`

#### compiler_flags

- Description: Toolchain-specific compiler flags. These flags will be passed only to the compiler.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["-std=c89", "-Wall", "-Wextra", "-Wconversion", "-pedantic"]`

#### linker_flags

- Description: Toolchain-specific linker flags. These flags will be passed only to the linker.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["-Wl,--gc-sections"]`

#### ext_list_creator_flags

- Description: Toolchain-specific extended list creator flags. These flags will be passed only to the extended list creator.
- Type: Array of Strings
- Mandatory Field: No, default value: `["--source", "--all-headers", "--demangle", "--disassemble", "--line-numbers", "--reloc", "--syms", "--wide"]`
- Example (same as default, but with short flags): `["-S", "-x", "-C", "-d", "-l", "-r", "-t", "-w"]`
