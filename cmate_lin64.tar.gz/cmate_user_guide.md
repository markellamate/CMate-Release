# CMate User Guide

## Description

CMate is yet another C/C++ build system. It is similar to the CMake and Meson build systems, but has fewer features and is simpler to use.

## Dependencies

CMate is a meta build system, it generates build files that can be executed by ninja (default) or make. The ninja and make executables shall be installed and shall be available in the PATH environment variable.

### Installing ninja

#### Installing ninja on Windows

1. Download the `ninja-win.zip` package from its [GitHub repository](https://github.com/ninja-build/ninja/releases)
2. Unzip it and copy the executable file to a suitable directory
3. Make sure that directory is available in the PATH environment variable
4. Restart CommandPrompt or PowerShell and execute `ninja --version` to see if ninja works

#### Installing ninja on Linux

Option A (recommended):

1. Execute the following command in Shell: `sudo apt update && sudo apt install ninja-build`
2. Restart Shell and execute `ninja --version` to see if ninja works

Option B (if the most recent version is needed):

1. Download the `ninja-linux.zip` package from its [GitHub repository](https://github.com/ninja-build/ninja/releases)
2. Unzip it and copy the executable file to a suitable directory
3. Make sure that directory is available in the PATH environment variable
4. Restart Shell and execute `ninja --version` to see if ninja works

### Installing make

#### Installing make on Windows

Option A (recommended):

1. Download the most recent version of MinGW64-GCC from [winlibs.com](https://winlibs.com)
    - The downloadable packages are under the `Release versions` / `UCRT runtime` section of the web-page
    - E.g. [GCC 16.1.0 (with POSIX threads) + MinGW-w64 14.0.0 (UCRT) - release 3](https://github.com/brechtsanders/winlibs_mingw/releases/download/16.1.0posix-14.0.0-ucrt-r3/winlibs-x86_64-posix-seh-gcc-16.1.0-mingw-w64ucrt-14.0.0-r3.zip)
2. Unzip it and search for the `mingw32-make.exe` executable file in the `bin` directory
3. If it is there, copy it to a suitable directory, then rename it to `make.exe`
4. Make sure that directory is available in the PATH environment variable
5. Restart CommandPrompt or PowerShell and execute `make --version` to see if make works

Option B (if Option A fails, build make from source):

1. Download the most recent make source package from [ftp.gnu.org](https://ftp.gnu.org/gnu/make/?C=M;O=D), e.g. `make-4.4.1.tar.gz`
2. Unzip it and open CommandPrompt or PowerShell in the directory that contains the file `build_w32.bat`
3. Depending on which toolchain is to be used to build make
    - MSVC toolchain: Execute the `.\build_w32.bat` command to start the building process (this is the recommended option)
    - GCC toolchain: Execute the `.\build_w32.bat gcc` command to start the building process
4. Depending on which toolchain was used to build make
    - MSVC toolchain: the `gnumake.exe` executable is located in the `WinRel` directory
    - GCC toolchain: the `gnumake.exe` executable is located in the `GccRel` directory
5. Rename the `gnumake.exe` file to `make.exe`, copy it to a suitable directory
6. Make sure that directory is available in the PATH environment variable
7. Restart CommandPrompt or PowerShell and execute `make --version` to see if make works

#### Installing make on Linux

1. Execute the following command in Shell: `sudo apt update && sudo apt install make`
2. Restart Shell and execute `make --version` to see if make works

## Toolchain compatibility

CMate is currently compatible with GCC and LLVM-based toolchains.

## Command line arguments

Please, execute the `cmate --help` command to see a summary of accepted command line arguments.

## Examples

There are two examples, a simple and an advanced one. To make the examples fully functional, please follow the steps below.

### Examples on Windows

1. Install ninja as described above
2. Install a GCC-based toolchain that can build an executable application for x86_64 target
    1. Download the most recent version of MinGW64-GCC from [winlibs.com](https://winlibs.com)
        - The downloadable packages are under the `Release versions` / `UCRT runtime` section of the web-page
        - E.g. [GCC 16.1.0 (with POSIX threads) + MinGW-w64 14.0.0 (UCRT) - release 3](https://github.com/brechtsanders/winlibs_mingw/releases/download/16.1.0posix-14.0.0-ucrt-r3/winlibs-x86_64-posix-seh-gcc-16.1.0-mingw-w64ucrt-14.0.0-r3.zip)
    2. Unzip it and copy the directory to a suitable directory
    3. Make sure the `bin` directory of the toolchain is available in the PATH environment variable
    4. Restart CommandPrompt or PowerShell and execute `gcc -v` to see if GCC works
3. Execute `cmate init --example simple` or `cmate init --example advanced` in an empty directory

### Examples on Linux

1. Install ninja as described above
2. Install a GCC-based toolchain that can build an executable application for x86_64 target
    1. Execute the following command in Shell: `sudo apt update && sudo apt install build-essential`
    2. Restart Shell and execute `gcc -v` to see if GCC works
3. Execute `cmate init --example simple` or `cmate init --example advanced` in an empty directory

## Creating new CMate project

### Using CMate without an Integrated Development Environment

Execute the `cmate init` or `cmate new my_new_cmate_project` to create a starting point to your project.
These commands create a `cmate.rhai` file that can be further tailored to the project needs.

### Using CMate with Visual Studio Code

Execute the `cmate init --ide vscode` or `cmate new my_new_cmate_project --ide vscode` to create a starting point to your project. These commands create a `cmate.rhai` file as well as VSCode-specific files that help with build tasks (`tasks.json`) and intelli-sense (`c_cpp_properties.json`) inside VSCode.

The json files are filled with default build tasks and intelli-sense configurations. These json files can be extended by simply adding more build tasks and intelli-sense configurations. The added build task labels and intelli-sense configuration names shall not start with the `####` string, otherwise they will be overwritten when CMate regenerates the json files.

After modifying the `cmate.rhai` file, CMate needs to be executed to update the json files too. Because of this, please run a CMate build task in VSCode (e.g. `#### [ All Configs ] # Clean` or `#### [ All Configs ] # ReBuild`) every time after modifying the `cmate.rhai` file.

### Modifying the cmate.rhai file to the project needs

Please, see the `cmate_reference_manual.md` document to learn about the structure of the `cmate.rhai` file.
