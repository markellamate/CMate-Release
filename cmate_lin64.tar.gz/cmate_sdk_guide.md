# CMate Software Development Kit Guide

## Description

CMate can be used in a custom software using the CMate static library.

## Compatibility

The static library is compatible with the followng toolchains.

- On Windows

  - The `libcmate.a` is compatible with GCC and LLVM-based toolchains.
  - The `cmate.lib` is compatible with Rust and MSVC toolchains.

- On Linux:

  - The `libcmate.a` is compatible with Rust, GCC and LLVM-based toolchains.

## Toolchain versions

The static library is built using the following toolchain versions.

### Rust toolchain

```bash
$ rustc --version --verbose
rustc 1.98.0 (88d9e12ae 2026-08-18)
binary: rustc
commit-hash: 88d9e12ae178fab0fb5cc050a94da85685d449ea
commit-date: 2026-08-18
host: x86_64-unknown-linux-gnu
release: 1.98.0
LLVM version: 22.1.8
```

### GCC toolchain

```bash
$ gcc -v
Using built-in specs.
COLLECT_GCC=gcc
COLLECT_LTO_WRAPPER=/usr/lib/gcc/x86_64-linux-gnu/11/lto-wrapper
OFFLOAD_TARGET_NAMES=nvptx-none:amdgcn-amdhsa
OFFLOAD_TARGET_DEFAULT=1
Target: x86_64-linux-gnu
Configured with: ../src/configure -v --with-pkgversion='Ubuntu 11.4.0-1ubuntu1~22.04.3' --with-bugurl=file:///usr/share/doc/gcc-11/README.Bugs --enable-languages=c,ada,c++,go,brig,d,fortran,objc,obj-c++,m2 --prefix=/usr --with-gcc-major-version-only --program-suffix=-11 --program-prefix=x86_64-linux-gnu- --enable-shared --enable-linker-build-id --libexecdir=/usr/lib --without-included-gettext --enable-threads=posix --libdir=/usr/lib --enable-nls --enable-bootstrap --enable-clocale=gnu --enable-libstdcxx-debug --enable-libstdcxx-time=yes --with-default-libstdcxx-abi=new --enable-gnu-unique-object --disable-vtable-verify --enable-plugin --enable-default-pie --with-system-zlib --enable-libphobos-checking=release --with-target-system-zlib=auto --enable-objc-gc=auto --enable-multiarch --disable-werror --enable-cet --with-arch-32=i686 --with-abi=m64 --with-multilib-list=m32,m64,mx32 --enable-multilib --with-tune=generic --enable-offload-targets=nvptx-none=/build/gcc-11-0odw26/gcc-11-11.4.0/debian/tmp-nvptx/usr,amdgcn-amdhsa=/build/gcc-11-0odw26/gcc-11-11.4.0/debian/tmp-gcn/usr --without-cuda-driver --enable-checking=release --build=x86_64-linux-gnu --host=x86_64-linux-gnu --target=x86_64-linux-gnu --with-build-config=bootstrap-lto-lean --enable-link-serialization=2
Thread model: posix
Supported LTO compression algorithms: zlib zstd
gcc version 11.4.0 (Ubuntu 11.4.0-1ubuntu1~22.04.3) 
```

## CMate Rust API

```rust
unsafe extern "Rust" {
    ///
    /// Runs the given project using the `cmate` runtime and returns its output.
    ///
    /// This is exposed as an `extern "Rust"` entry point so it can be called
    /// across a crate/dylib boundary (e.g. from a plugin host or dynamically
    /// loaded module) while still using Rust's native ABI and types.
    ///
    /// # Arguments
    ///
    /// * `argv` - The argument list to pass through to the project's entry
    ///   point, analogous to `std::env::args()` but without the program name.
    ///
    /// # Returns
    ///
    /// * `Ok(String)` - The captured output produced by running the project
    ///   (e.g. combined stdout, or a result summary), on success.
    /// * `Err(String)` - A human-readable error message describing why the
    ///   project could not be run (e.g. project not found, invalid arguments,
    ///   or a runtime failure during execution).
    ///
    /// # Errors
    ///
    ///   See the `Returns` section for the description of errors.
    ///
    /// # Examples
    ///
    /// ```
    /// unsafe extern "Rust" {
    ///     pub unsafe fn cmate_rust_run(argv: &[&str]) -> Result<String, String>;
    /// }
    ///
    /// fn main() {
    ///     let result = unsafe { cmate_rust_run(&["--help"]) };
    ///     match result {
    ///         Ok(info) => println!("CMate success. Info:\n\n{info}\n"),
    ///         Err(error) => println!("CMate error. Error:\n\n{error}\n"),
    ///     }
    /// }
    /// ```
    ///
    /// # Safety
    ///
    /// This function is not marked `unsafe` and does not take raw pointers,
    /// but because it is declared `extern "Rust"`, it must only be called
    /// from code compiled with a compatible Rust compiler/ABI version — it
    /// is **not** safe to call across an FFI boundary from C or another
    /// language, or between binaries built with mismatched `rustc` versions.
    ///
    pub unsafe fn cmate_rust_run(argv: &[&str]) -> Result<String, String>;
}
```

## CMate C API

```c
///
/// Runs the given project using the `cmate` runtime and returns its output,
/// writing the result into a caller-provided buffer.
///
/// This is the C-ABI counterpart to [`cmate_rust_run`], intended to be
/// called from non-Rust code (or across a `dylib`/FFI boundary) using
/// C-style null-terminated strings and a caller-owned output buffer
/// instead of Rust's `String`/`Result` types.
///
/// # Arguments
///
/// * `argv` - Pointer to a null-terminated array of null-terminated C
///   strings, analogous to a C `argv`. The array itself must be
///   terminated by a null pointer, and each element must point to a
///   valid null-terminated string.
/// * `resultbuf` - Pointer to a caller-allocated buffer that will receive
///   the null-terminated result (success output or error message) on
///   return.
/// * `resultcap` - The capacity, in bytes, of `resultbuf`. The function
///   will not write more than this many bytes, including the terminating
///   null byte.
///
/// # Returns
///
/// An `isize` status code:
/// * A zero value indicates success.
/// * A non-zero value indicates failure.
///
/// # Examples
///
/// ```
/// /*
///  * Do not forget to also link the following libraries to you application:
///  * Windows: `ws2_32`, `ntdll`, `userenv`
///  * Linux: `m`
///  */
/// #include <stdio.h>
/// #include <stdint.h>
/// extern intptr_t cmate_c_run(const char * const * const argv, char * const resultbuf, const uintptr_t resultcap);
/// int main(void) {
///     intptr_t result;
///     char message[1024U];
///     const char * const argv[] = { "--help", NULL };
///     result = cmate_c_run(argv, message, sizeof(message));
///     if (result == 0) { printf("CMate success. Info:\n\n%s\n", message); }
///     else             { printf("CMate error. Error:\n\n%s\n", message); }
///     return 0;
/// }
/// ```
///
/// # Panics
///
/// The function panics if the pointers are null.
///
/// # Safety
///
/// Do not pass null-pointers to the function. In addition, callers must
/// ensure that:
///
/// * `argv` points to a valid, null-terminated array of valid,
///   null-terminated C strings, all of which remain valid for the
///   duration of the call.
/// * `resultbuf` points to a writable buffer of at least `resultcap`
///   bytes, valid for the duration of the call.
/// * `resultbuf` and `resultcap` accurately describe the same
///   allocation — passing a `resultcap` larger than the actual buffer
///   is undefined behavior.
/// * The memory regions referenced by `argv`, and `resultbuf`
///   do not overlap in a way that violates Rust's aliasing rules.
///
extern intptr_t cmate_c_run(const char * const * const argv, char * const resultbuf, const uintptr_t resultcap);
```

## CMate Rust SDK example

```rust
unsafe extern "Rust" {
    pub unsafe fn cmate_rust_run(argv: &[&str]) -> Result<String, String>;
}
fn main() {
    let result = unsafe { cmate_rust_run(&["--help"]) };
    match result {
        Ok(info) => println!("CMate success. Info:\n\n{info}\n"),
        Err(error) => println!("CMate error. Error:\n\n{error}\n"),
    }
}
```

## CMate C SDK example

```c
/*
 * Do not forget to also link the following libraries to you application:
 * Windows: `ws2_32`, `ntdll`, `userenv`
 * Linux: `m`
 */
#include <stdio.h>
#include <stdint.h>
extern intptr_t cmate_c_run(const char * const * const argv, char * const resultbuf, const uintptr_t resultcap);
int main(void) {
    intptr_t result;
    char message[1024U];
    const char * const argv[] = { "--help", NULL };
    result = cmate_c_run(argv, message, sizeof(message));
    if (result == 0) { printf("CMate success. Info:\n\n%s\n", message); }
    else             { printf("CMate error. Error:\n\n%s\n", message); }
    return 0;
}
```
