# CMate Reference Manual

## Configuration file of a CMate project

The project configuration file of CMate is one and only one [rhai](https://rhai.rs/book/about/features.html) script file. This rhai script file serves the very same purpose as a CMakeLists.txt file for the CMake build system, or a meson.build file for the Meson build system. It contains information necessary for the building of the C/C++ project.

### The anatomy of a CMate project configuration file

The rhai script language uses a Rust-like syntax with dynamic typing.

#### General information about the anatomy of a CMate project configuration file

- CMate project configuration files contain a lot of file system paths. To make CMate work on every computer, it is highly recommended to enter only relative paths in the CMate project configuration file.
- Every path is relative to the containing directory of the CMate project configuration file unless stated otherwise.
- CMate works with absolute paths internally, but generates build files with relative paths.

#### Create project configuration

The input rhai script file can contain exactly one project configuration. A project configuration variable can be created by the following code.

Example:

```rust
let project_config = create_project_config();
```

This code creates a variable named `project_config` which is a structure with multiple fields. See below for the explanation of all project configuration structure fields.

#### Create build configurations

The input rhai script file can contain multiple build configurations. A build configuration variable can be created by the following code.

Example:

```rust
let build_config_1 = create_build_config();
let build_config_2 = create_build_config();
```

This code creates multiple variables named `build_config_1` and `build_config_2` which are structures with multiple fields. See below for the explanation of all build configuration structure fields.

#### Create a CMate project

The input rhai script file shall always end with the following code. Note, that there is no `;` at the end of the line.

Example:

```rust
create_project(project_config, [build_config_1, build_config_2])
```

- The first parameter of `create_project()` specifies the project configuration variable which is created by the `ProjectConfig_create()` function.
- The second parameter specifies the array of build configuration variables which are created by the `BuildConfig_create()` function. If the build configurations depend on each other, it is highly recommended to list the build configurations in dependency order.

#### Import a build configuration from another CMate project

A build configuration from another CMate project can be reused by importing it into the current project.

Example:

```rust
let imported_build_config = import_build_config("path/to/another/project/rhai/script/file.rhai", "build_config_name_from_another_project");
```

- The first parameter of `import_build_config()` specifies the path to the rhai script file of the other project.
- The second parameter specifies the name of the build configuration to import from that project.

After importing, the build configuration fields may be modified as needed to match the requirements of the current project.

After importing, without modifying the imported build configuration, the imported build configuration still contains the absolute paths of the other CMate project.
As a result, the artifact files generated from the imported build configuration are placed in the build directory of the other CMate project.

To place the artifact files generated from the imported build configuration to the build directory of the current CMate project, change the build directory of the imported build configuration to a directory inside the current CMate project.

Example:

```shell
C:.
|
+---ProjectDirParent
|   |   cmate_parent.rhai
|   |
|   +---BuildDirParent
|   |       artifact_parent.exe
|   |
|   \---ProjectDirChild
|       |   cmate_child.rhai
|       |
|       \---BuildDirChild
|               artifact_child.exe
```

```rust
///
/// CMate file: C:/ProjectDirParent/ProjectDirChild/cmate_child.rhai
///
let project_config     = create_project_config();
let build_config_child = create_build_config();
// ...
build_config_child.build_name         = "BuildDirChild";
build_config_child.build_dir          = "BuildDirChild"; // This path is resolved internally by CMate to: C:/ProjectDirParent/ProjectDirChild/BuildDirChild
build_config_child.install_dir        = "BuildDirChild"; // This path is resolved internally by CMate to: C:/ProjectDirParent/ProjectDirChild/BuildDirChild
build_config_child.artifact_base_name = "artifact_child";
build_config_child.artifact_extension = ".exe";
build_config_child.post_build_steps   = ["./BuildDirChild/artifact_child.exe"]; // This path is resolved internally by CMate to: C:/ProjectDirParent/ProjectDirChild/BuildDirChild/artifact_child.exe
// ...
create_project(project_config, [build_config_child])
```

```rust
///
/// CMate file: C:/ProjectDirParent/cmate_parent.rhai
///
let project_config      = create_project_config();
let build_config_parent = create_build_config();
// ...
build_config_parent.build_name         = "BuildDirParent";
build_config_parent.build_dir          = "BuildDirParent"; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirParent
build_config_parent.install_dir        = "BuildDirParent"; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirParent
build_config_parent.artifact_base_name = "artifact_parent";
build_config_parent.artifact_extension = ".exe";
build_config_parent.post_build_steps   = ["./BuildDirParent/artifact_parent.exe"]; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirParent/artifact_parent.exe
// ...
let imported_build_config_child = import_build_config("./ProjectDirChild/cmate_child.rhai", "BuildDirChild");
// ...
// The fields of `imported_build_config_child` can be modified here.
// ...
create_project(project_config, [build_config_parent, imported_build_config_child])
```

Without modifying the imported build configuration, the artifact file `artifact_child.exe` is generated to the build directory of the child project (`C:/ProjectDirParent/ProjectDirChild/BuildDirChild`).

By modifying the build directory and post-build steps of the imported build configuration,

```rust
// ...
// Without modifying:
// imported_build_config_child.build_dir = "C:/ProjectDirParent/ProjectDirChild/BuildDirChild"
// ...
imported_build_config_child.build_dir        = "BuildDirChild";                        // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirChild
imported_build_config_child.install_dir      = "BuildDirChild";                        // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirChild
imported_build_config_child.post_build_steps = ["./BuildDirChild/artifact_child.exe"]; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirChild/artifact_child.exe
// ...
// After modifying:
// imported_build_config_child.build_dir = "C:/ProjectDirParent/BuildDirChild"
// ...
```

the artifact file `artifact_child.exe` is generated to the build directory of the parent project (`C:/ProjectDirParent/BuildDirChild`).

#### CMate utility functions - File I/O

- `let existing_file = is_existing_file("path/to/file")`: Returns whether `path/to/file` is pointing to a file and exists.

- `let existing_dir = is_existing_dir("path/to/dir")`: Returns whether `path/to/dir` is pointing to a directory and exists.

- `write_file("path/to/file", "string")`: Writes `string` to `path/to/file`. Creates the file and all intermediate directories if they do not exist.

- `append_file("path/to/file", "string")`: Appends `string` to `path/to/file`. Creates the file and all intermediate directories if they do not exist.

- `let content = read_file("path/to/file")`: Reads the content of the `path/to/file`.

- `copy_file("path/to/source/file", "path/to/destination/file")`: Copies `path/to/source/file` to `path/to/destination/file`. Both paths must be paths to files (not paths to directories).

- `copy_dir("path/to/source/dir", "path/to/destination/dir")`: Copies all content recursively from `path/to/source/dir` to `path/to/destination/dir`. Both paths must be paths to directories (not paths to files).

- `delete_file("path/to/file")`: Deletes `path/to/file`.

- `delete_dir("path/to/dir")`: Deletes all content recursively from `path/to/dir`, then deletes `path/to/dir` itself.

- `create_dir("path/to/dir")`: Creates `path/to/dir`.

- `reset_dir("path/to/dir")`: Deletes `path/to/dir`, then creates it.

#### CMate utility functions - Date and Time

- `let date = get_short_date()`: Returns the current date in `YYY-MM-DD` format.

- `let date = get_long_date()`: Returns the current date in `YYY-MM-DD HH:MM:SS` format.

#### CMate utility functions - Git

- `let url = get_git_repo_url()`: Returns the remote URL of the Git repository. In case of any errors, this function returns an empty string. Corresponds to the following command: `git remote get-url origin`.

- `let hash = get_git_short_hash()`: Returns the Git hash of the last commit in short form. In case of any errors, this function returns an empty string. Corresponds to the following command: `git rev-parse --short HEAD`.

- `let hash = get_git_full_hash()`: Returns the Git hash of the last commit in long form. In case of any errors, this function returns an empty string. Corresponds to the following command: `git rev-parse HEAD`.

- `let tag = get_git_last_tag()`: Returns the name of the last Git tag. In case of any errors, this function returns an empty string. Corresponds to the following command: `git describe --tags --abbrev=0`.

- `let tag = get_git_exact_tag()`: Returns the name of the exact Git tag that points to the latest commit. In case of any errors, this function returns an empty string. Corresponds to the following command: `git describe --tags --exact-match HEAD`.

#### CMate utility functions - Platform

- `let os = get_os()`: Returns the current operating system as a string, `windows` or `linux`.

- `let process_result = run_foreground_process("program", ["arg1", "arg2", "arg3"])`: Runs `program` (with arguments `arg1`, `arg2` and `arg3`) in the foreground (waits for the completion of the process). Returns the result as a map. The returned map can be used like this:

  - `process_result.code`: Contains the exit code of the completed foreground process.
  - `process_result.stdout`: Contains the standard output messages printed by the completed foreground process.
  - `process_result.stderr`: Contains the standard error messages printed by the completed foreground process.

- `run_background_process("program", ["arg1", "arg2", "arg3"])`: Runs `program` (with arguments `arg1`, `arg2` and `arg3`) in the background (does not wait for the completion of the process). Before termination, CMate closes the launched background process.

#### CMate utility functions - Regular Expressions

- `let compiled_regex = re_compile("regex_string")`: Compiles `regex_string` and returns a compiled regular expression object. This regular expression object is used in all of the following regular expression functions. An invalid pattern raises an error. The accepted syntax can be found on [this page](https://docs.rs/regex/latest/regex/#syntax). Inline flags (`(?i)`, `(?m)`, `(?s)`, `(?x)`) shall be applied directly in the pattern.

- `let is_match = re_is_match(compiled_regex, "string")`: Returns whether there is a match for the regular expression in the given `string`.

  Example:

  ```rust
  let regex = re_compile("^\\d+$");

  print(re_is_match(regex, "12345")); // true
  print(re_is_match(regex, "12a45")); // false
  ```

- `let first_match = re_find_first_match(compiled_regex, "string")`: Returns the first match (with groups) for the regular expression in the given `string`. Returns `()` if there is no match, otherwise returns the result as a map. The returned map can be used like this:

  - `first_match.groups[0].text`: Contains the whole matched text.
  - `first_match.groups[0].start`: Contains the starting byte offset (not character offset) of the whole matched text.
  - `first_match.groups[0].end`: Contains the ending byte offset (not character offset) (exclusive) of the whole matched text.
  - `first_match.groups[GROUP_INDEX]`: `GROUP_INDEX` > 0. Indexed group access. Contains information for group `GROUP_INDEX`. `()` means that the group did not take part in the match.
  - `first_match.groups[first_match.names.GROUP_NAME]`: Named group access. Contains information for group `GROUP_NAME`. `()` means that the group did not take part in the match.
  - `first_match.names` is an empty map if there are no named groups in the regular expression.

  Example:

  ```rust
  let regex = re_compile("(?P<key>\\w+)=(?P<value>\\d+)");
  let first_match = re_find_first_match(regex, "x: speed=42, depth=78, style=99");

  print(first_match.names);                                 // #{"key": 1, "value": 2}
  print(first_match.groups[0]);                             // #{"end": 11, "start": 3, "text": "speed=42"}
  print(first_match.groups[0].text);                        // speed=42
  print(first_match.groups[first_match.names.key].text);    // speed
  print(first_match.groups[first_match.names.value].text);  // 42
  print(first_match.groups[first_match.names.value].start); // 9

  print(re_find_first_match(regex, "nothing here")); // ()
  ```

- `let all_matches = re_find_all_matches(compiled_regex, "string")`: Returns all matches (with groups) for the regular expression in the given `string`. Returns the result as a map. The returned map can be used like this:

  - `all_matches.matches[MATCH_INDEX].groups[0].text`: Contains the whole matched text.
  - `all_matches.matches[MATCH_INDEX].groups[0].start`: Contains the starting byte offset (not character offset) of the whole matched text.
  - `all_matches.matches[MATCH_INDEX].groups[0].end`: Contains the ending byte offset (not character offset) (exclusive) of the whole matched text.
  - `all_matches.matches[MATCH_INDEX].groups[GROUP_INDEX]`: `GROUP_INDEX` > 0. Indexed group access. Contains information for group `GROUP_INDEX`. `()` means that the group did not take part in the match.
  - `all_matches.matches[MATCH_INDEX].groups[all_matches.names.GROUP_NAME]`: Named group access. Contains information for group `GROUP_NAME`. `()` means that the group did not take part in the match.
  - `all_matches.matches` is an empty array if there is no match.
  - `all_matches.names` is an empty map if there are no named groups in the regular expression.

  Example:

  ```rust
  let regex = re_compile("(?P<key>\\w+)=(?P<value>\\d+)");
  let all_matches = re_find_all_matches(regex, "x: speed=42, depth=78, style=99");

  print(all_matches.names);                           // #{"key": 1, "value": 2}
  for m in all_matches.matches {
      print(m.groups[0]);                             // #{"end": 11, "start": 3, "text": "speed=42"}; #{"end": 21, "start": 13, "text": "depth=78"}; #{"end": 31, "start": 23, "text": "style=99"}
      print(m.groups[0].text);                        // speed=42; depth=78; style=99
      print(m.groups[all_matches.names.key].text);    // speed; depth; style
      print(m.groups[all_matches.names.value].text);  // 42; 78; 99
      print(m.groups[all_matches.names.value].start); // 9; 19; 29
  }

  print(re_find_all_matches(regex, "nothing here")); // #{"matches": [], "names": #{"key": 1, "value": 2}}
  ```

- `let first_text = re_find_first_text(compiled_regex, "string")`: Returns the first text that matches the regular expression in the given `string`. Returns `()` if there is no match, otherwise returns the result as a string.

  Example:

  ```rust
  let regex = re_compile("\\d+");

  print(re_find_first_text(regex, "a1 aaa b22 rrr c333")); // 1

  print(re_find_first_text(regex, "nothing here")); // ()
  ```

- `let all_texts = re_find_all_texts(compiled_regex, "string")`: Returns all texts that match the regular expression in the given `string`. Returns the result as an array of strings. The returned array is an empty array if there is no match.

  Example:

  ```rust
  let regex = re_compile("\\d+");

  print(re_find_all_texts(regex, "a1 aaa b22 rrr c333")); // ["1", "22", "333"]

  print(re_find_all_texts(regex, "nothing here")); // []
  ```

- `let string_array = re_split(compiled_regex, "string", limit, return_empty)`: Splits `string` at every match of the regular expression. `limit` can be used to control the maximum number of returned array elements. A `limit` of 0 means no limit. `return_empty` can be used whether to keep empty strings in the result. `limit` is the maximum number of pieces before empty strings are removed, so fewer may be returned when `return_empty` is `false`.

  Example:

  ```rust
  let regex = re_compile("\\d");

  print(re_split(regex, "0a1b22c333d4e555", 0, true));  // ["", "a", "b", "", "c", "", "", "d", "e", "", "", ""]
  print(re_split(regex, "0a1b22c333d4e555", 0, false)); // ["a", "b", "c", "d", "e"]
  print(re_split(regex, "0a1b22c333d4e555", 4, true));  // ["", "a", "b", "2c333d4e555"]
  print(re_split(regex, "0a1b22c333d4e555", 4, false)); // ["a", "b", "2c333d4e555"]
  ```

- `let replaced_string = re_replace(compiled_regex, "string", "replacement", limit)`: Replaces at most `limit` matches in `string` with `replacement`. A `limit` of 0 means all matches are replaced. `replacement` can contain the syntax `$N` and `$name` to match groups by index or by name. To control the name of the group more precisely, the syntax `${name}` can be used. An invalid group reference, e.g. `$nonexistent` expands to an empty string. To write a literal `$` in `replacement`, use `$$`.

  Example:

  ```rust
  let regex = re_compile("(?P<first>\\w+)\\s+(?P<last>\\w+)");

  print(re_replace(regex, "Arthur Morgan, John Marston, Micah Bell", "$last $first", 0)); // Morgan Arthur, Marston John, Bell Micah
  print(re_replace(regex, "Arthur Morgan, John Marston, Micah Bell", "$last $first", 2)); // Morgan Arthur, Marston John, Micah Bell

  print(re_replace(regex, "Arthur Morgan, John Marston, Micah Bell", "${first}_Somebody", 0)); // Arthur_Somebody, John_Somebody, Micah_Somebody
  ```

#### CMate hook functions - On successful exit

- `on_successful_exit_hook()`: Called before CMate terminates successfully. Signature: `fn on_successful_exit_hook() { /* Custom function implementation. */ }`

### Project configuration structure fields

#### project_name

- Description: The descriptive name of the project.
- Type: String
- Mandatory Field: Yes
- Examples: `"ExampleProject"`

#### parallel_build_jobs

- Description: The number of parallel build jobs ninja or make will use to execute the build process.
- Type: Integer
- Mandatory Field: No, default value: number of processor cores
- Examples: `1`, `8`

#### ide_type

- Description: The type of Integrated Development Environment support files to generate.
- Type: Array of Strings
- Mandatory Field: Yes
- Accepted Values: "vscode", "zed"
- Examples: `[]`, `["vscode"]`, `["zed"]`, `["vscode", "zed"]`

#### ide_dir

- Description: The base directory where the Integrated Development Environment support files are generated. In case of VSCode, this path shall not contain the final `.vscode` directory.
- Type: String
- Mandatory Field: Yes
- Examples: `"."`, `".."`, `"MyIdeDir"`

#### ide_builder

- Description: The application that executes the building process in the Integrated Development Environment. `BuildFrontend` means the application that generated the build files (and also can execute the generated build files), `BuildBackend` means the application that can execute the generated build files.
- Type: String
- Mandatory Field: Yes
- Accepted Values: "buildfrontend", "buildbackend"
- Examples: `"buildfrontend"`, `"buildbackend"`

### Build configuration structure fields

#### General information about the build configuration structure fields

- Some fields accept [glob](https://en.wikipedia.org/wiki/Glob_(programming)#Syntax) patterns. Glob patterns can be used to specify paths with wildcards. Besides the standard glob syntax elements (`*`, `?`, `[abc]`, `[a-z]`) that are listed on the above mentioned web page, the following glob pattern modifiers can be applied:
  - `|`: By default, if a glob pattern does not match any files or directories, CMate will report an error. This behavior can be altered with the `|` character. Starting the glob pattern with `|` tells CMate not complain when a glob pattern does not match any files or directories. The `|` glob pattern modifier allows an empty glob pattern match. The glob pattern won't be listed in the generated build files.
  - `!`: The `!` glob pattern modifier negates a glob pattern. The files or directories matching the negated glob pattern won't be listed in the generated build files. The `!` glob pattern modifier can be used for example to select all source files in a directory, except for specific source files.
  - `>`: The `>` glob pattern modifier forces a file or directory path to be listed in the generated build files even if that file or directory path does not exist. No other glob pattern characters can be used with the `>` glob pattern modifier. In other words, only exact relative or absolute paths (without any glob characters) of files or directories can be specified with the `>` glob pattern modifier. The `>` glob pattern modifier can be used for example to list those source files in the generated build files that are not existing when CMate generates the build files (e.g. because those source files are being generated by an other tool before the building process).
  - The above mentioned glob pattern modifier characters are mutually exclusive, which means only one of them can appear at most once at the very beginning of the glob pattern.

- Toolchain specific flags shall not be applied in most of the fields.
  - Do not insert the `-T` flag in the `linker_scripts` field.
  - Do not insert the `-L` flag in the `linker_search_dirs` field.
  - Do not insert the `-l` flag in the `linker_additional_libs` field.
  - Do not insert the `-I` flag in the `include_dirs` field.
  - Do not insert the `-include` flag in the `include_files` field.
  - Do not insert the `-D` flag in the `defined_preprocessor_macros` field.
  - Do not insert the `-U` flag in the `undefined_preprocessor_macros` field.
- Toolchain specific flags shall only be applied in the following fields:
  - `target_flags`, e.g. `"-march=x86-64"`
  - `asm_compiler_flags`, e.g. `"-std=c89"`, `"-Wall"`, `"-Wextra"`, `"-Wconversion"`, `"-pedantic"`
  - `c_compiler_flags`, e.g. `"-std=c89"`, `"-Wall"`, `"-Wextra"`, `"-Wconversion"`, `"-pedantic"`
  - `cpp_compiler_flags`, e.g. `"-std=c89"`, `"-Wall"`, `"-Wextra"`, `"-Wconversion"`, `"-pedantic"`
  - `linker_flags`, e.g. `"-Wl,--gc-sections"`
  - `archiver_flags`
  - `img_file_creator_flags`
  - `ext_list_creator_flags`, e.g. `"-S"`, `"-x"`, `"-C"`, `"-d"`, `"-l"`, `"-r"`, `"-t"`, `"-w"`
  - `size_printer_flags`, e.g. `"-A"`

#### build_name

- Description: The name of the build configuration. Every build configuration shall have a unique name.
- Type: String
- Mandatory Field: Yes
- Examples: `"Debug"`, `"Release"`

#### build_dir

- Description: The directory where the build files and the artifact files are generated. Every build configuration shall have a unique build directory.
- Type: String
- Mandatory Field: Yes
- Examples: `"Debug"`, `"Release"`, `"../BuildDir"`, `"ChildDir/BuildDir"`

#### install_dir

- Description: The directory where the artifact file is copied when CMate executes the install target. The directory is created if it does not exist.
- Type: String
- Mandatory Field: Yes
- Examples: `"Install"`

#### build_type

- Description: The type of the build configuration. Whether to build an executable file or build a static library file.
- Type: String
- Mandatory Field: Yes
- Accepted Values: "executable", "staticlib"
- Examples: `"executable"`, `"staticlib"`

#### artifact_base_name

- Description: The base name of the artifact file. The artifact file is the final product of the build, an executable file or a static library file.
- Type: String
- Mandatory Field: Yes
- Examples: `"myexecutable"`, `"mylib"`

#### artifact_extension

- Description: The extension of the artifact file. The artifact file is the final product of the build, an executable file or a static library file. This field is only taken into account if the build type is executable. The artifact file will have a `lib` prefix and a `.a` extension if the build type is static library.
- Type: String
- Mandatory Field: Yes
- Examples: `".exe"`, `".elf"`, `""`

#### toolchain_family

- Description: The toolchain family / toolchain kind.
- Type: String
- Mandatory Field: Yes
- Accepted Values: "llvmgcc", "sdcc", "msvc"
- Examples: `"llvmgcc"`, `"sdcc"`, `"msvc"`

#### toolchain_prefix

- Description: A string that will act as a prefix when invoking toolchain executables (compiler, linker, archiver, etc.). The toolchain executable is invoked prefixed by this value without any spaces or additional characters.
- Type: String
- Mandatory Field: Yes
- Examples: `"arm-none-eabi-"`, `""`

#### asm_compiler_path, c_compiler_path, cpp_compiler_path, linker_path, archiver_path, img_file_creator_path, ext_list_creator_path, size_printer_path

- Description: The toolchain executables.
- Type: String
- Mandatory Field: Yes
- Example for Desktop GCC (in order): `"gcc"`, `"gcc"`, `"gcc"`, `"gcc"`, `"ar"`, `"objcopy"`, `"objdump"`, `"size"`
- Example for ARM32 GCC (in order): `"arm-none-eabi-gcc"`, `"arm-none-eabi-gcc"`, `"arm-none-eabi-gcc"`, `"arm-none-eabi-gcc"`, `"arm-none-eabi-ar"`, `"arm-none-eabi-objcopy"`, `"arm-none-eabi-objdump"`, `"arm-none-eabi-size"`
- Example for LLVM (in order): `"clang"`, `"clang"`, `"clang"`, `"clang"`, `"llvm-ar"`, `"llvm-objcopy"`, `"llvm-objdump"`, `"llvm-size"`

#### pre_build_steps, post_build_steps

- Description: Commands to execute before or after the build. The post-build step is only executed if the build process succeeds. The commands are executed as subprocesses. Multiple commands can be separated with the `;` character.
- Type: Array of Strings
- Mandatory Field: Yes
- Example for running the built application as post-build step: `["./Debug/program.exe"]`
- Example for running a Windows shell command as post-build step: `["cmd", "/c", "echo Build Finished"]`
- Example for running a Linux shell command as post-build step: `["sh", "-c", "echo Build Finished"]`
- Example for running multiple post-build steps: `["post", "build", "step", "1", ";", "post", "build", "step", "2", ";", "post", "build", "step", "3"]`
- Example for loading an executable file to a microcontroller with an already running OpenOCD and GDB: `["arm-none-eabi-gdb", "-q", "-ex", "set confirm off", "-ex", "target remote localhost:3333", "-ex", "monitor reset halt", "-ex", "load Debug/program.elf", "-ex", "continue", "-ex", "kill", "-ex", "quit"]`

#### dependency_build_configs

- Description: The names of the build configurations that are the dependencies of the current build configuration. Dependency build configurations will be built prior to the current build configuration. Multiple build configurations can be chained with this option. Can be useful for example when an executable file depends on a static library file.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["staticlib"]`

#### linker_scripts

- Description: The linker scripts to use when linking the object files to an executable file.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["memregions.ld", "linker.ld"]`

#### linker_search_dirs

- Description: Additional directories where the linker will search for additional libraries.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["staticlib"]`

#### linker_additional_libs

- Description: Additional libraries to link to the executable. Do not include the `lib` prefix and `.a` extension when specifying additional libraries, those are added automatically by the toolchain. So, if `libmylib.a` is a static library that should be linked to the executable, specify `mylib` here.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["mylib"]`

#### include_dirs

- Description: Include directories. This field accepts glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["inc"]`
- Examples with glob syntax:
  - Lists all directories in the current directory non-recursively, fails in case of empty match: `["*"]`
  - Lists all directories in the current directory non-recursively, does not fail in case of empty match: `["|*"]`
  - Lists all directories in the current directory recursively, fails in case of empty match: `["**"]`
  - Lists all directories in the current directory recursively, does not fail in case of empty match: `["|**"]`
  - Lists all directories with names starting with `src` in the current directory non-recursively, fails in case of empty match: `["src*"]`
  - Lists all directories with names starting with `src` in the current directory non-recursively, does not fail in case of empty match: `["|src*"]`
  - Lists all directories with names starting with `src` in the current directory recursively, fails in case of empty match: `["**/src*"]`
  - Lists all directories with names starting with `src` in the current directory recursively, does not fail in case of empty match: `["|**/src*"]`
  - Lists all directories in the current directory recursively, excluding all directories recursively with name `obj`: `["**", "!**/obj"]`
  - Results in the path `generate/inc` even if the path `generate/inc` does not exist at build file generation time: `[">generate/inc"]`

#### include_files

- Description: Header files that will be pre-included to the beginning of all source files. This field accepts glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["mypreincludedheaderfile.h"]`
- Examples with glob syntax:
  - Lists all C/C++ header files in the current directory non-recursively, fails in case of empty match: `["*.h", "*.hpp"]`
  - Lists all C/C++ header files in the current directory non-recursively, does not fail in case there are no C++ header files: `["*.h", "|*.hpp"]`
  - Lists all C/C++ header files in the current directory recursively, fails in case of empty match: `["**/*.h", "**/*.hpp"]`
  - Lists all C/C++ header files in the current directory recursively, does not fail in case there are no C++ header files: `["**/*.h", "|**/*.hpp"]`
  - Lists all C/C++ header files with names starting with `header_file_` in the current directory non-recursively, fails in case of empty match: `["header_file_*.h", "header_file_*.hpp"]`
  - Lists all C/C++ header files with names starting with `header_file_` in the current directory non-recursively, does not fail in case there are no C++ header files: `["header_file_*.h", "|header_file_*.hpp"]`
  - Lists all C/C++ header files with names starting with `header_file_` in the current directory recursively, fails in case of empty match: `["**/header_file_*.h", "**/header_file_*.hpp"]`
  - Lists all C/C++ header files with names starting with `header_file_` in the current directory recursively, does not fail in case there are no C++ header files: `["**/header_file_*.h", "|**/header_file_*.hpp"]`
  - Lists all C/C++ header files in the current directory recursively, excluding all header files recursively with base name `wrong_header_file`: : `["**/*.h", "**/*.hpp", "!**/wrong_header_file.h", "!**/wrong_header_file.hpp"]`
  - Results in the path `generate/inc/generated_header_file.h` even if the path `generate/inc/generated_header_file.h` does not exist at build file generation time: `[">generate/inc/generated_header_file.h"]`

#### asm_source_files, c_source_files, cpp_source_files

- Description: Assembly, C, C++ source files. These fields accept glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["src/lib.c", "src/main.c"]`
- Examples with glob syntax:
  - Lists all C/C++ source files in the current directory non-recursively, fails in case of empty match: `["*.c", "*.cpp"]`
  - Lists all C/C++ source files in the current directory non-recursively, does not fail in case there are no C++ source files: `["*.c", "|*.cpp"]`
  - Lists all C/C++ source files in the current directory recursively, fails in case of empty match: `["**/*.c", "**/*.cpp"]`
  - Lists all C/C++ source files in the current directory recursively, does not fail in case there are no C++ source files: `["**/*.c", "|**/*.cpp"]`
  - Lists all C/C++ source files with names starting with `source_file_` in the current directory non-recursively, fails in case of empty match: `["source_file_*.c", "source_file_*.cpp"]`
  - Lists all C/C++ source files with names starting with `source_file_` in the current directory non-recursively, does not fail in case there are no C++ source files: `["source_file_*.c", "|source_file_*.cpp"]`
  - Lists all C/C++ source files with names starting with `source_file_` in the current directory recursively, fails in case of empty match: `["**/source_file_*.c", "**/source_file_*.cpp"]`
  - Lists all C/C++ source files with names starting with `source_file_` in the current directory recursively, does not fail in case there are no C++ source files: `["**/source_file_*.c", "|**/source_file_*.cpp"]`
  - Lists all C/C++ source files in the current directory recursively, excluding all source files recursively with base name `wrong_source_file`: : `["**/*.c", "**/*.cpp", "!**/wrong_source_file.c", "!**/wrong_source_file.cpp"]`
  - Results in the path `generate/src/generated_source_file.c` even if the path `generate/src/generated_source_file.c` does not exist at build file generation time: `[">generate/src/generated_source_file.c"]`

#### additional_objects

- Description: Additional object files to link to the executable or to add to the static library. This field accepts glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["obj/add.c.o"]`
- Examples with glob syntax:
  - Lists all object files in the current directory non-recursively, fails in case of empty match: `["*.o"]`
  - Lists all object files in the current directory non-recursively, does not fail in case there are no object files: `["|*.o"]`
  - Lists all object files in the current directory recursively, fails in case of empty match: `["**/*.o"]`
  - Lists all object files in the current directory recursively, does not fail in case there are no object files: `["|**/*.o"]`
  - Lists all object files with names starting with `object_file_` in the current directory non-recursively, fails in case of empty match: `["object_file_*.o"]`
  - Lists all object files with names starting with `object_file_` in the current directory non-recursively, does not fail in case there are no object files: `["|object_file_*.o"]`
  - Lists all object files with names starting with `object_file_` in the current directory recursively, fails in case of empty match: `["**/object_file_*.o"]`
  - Lists all object files with names starting with `object_file_` in the current directory recursively, does not fail in case there are no object files: `["|**/object_file_*.o"]`
  - Lists all object files in the current directory recursively, excluding all object files recursively with base name `wrong_object_file`: : `["**/*.o", "!**/wrong_object_file.o"]`
  - Results in the path `generate/obj/generated_object_file.o` even if the path `generate/obj/generated_object_file.o` does not exist at build file generation time: `[">generate/obj/generated_object_file.o"]`

#### defined_preprocessor_macros

- Description: Defined preprocessor macros.
- Type: Array of Strings
- Mandatory Field: Yes
- Example without value: `["MYMACRO"]`
- Example with integer value: `["MYMACROWITHINTVALUE=42"]`
- Example with string value: `["MYMACROWITHSTRINGVALUE='Hello\r\nWorld!'"]`

#### undefined_preprocessor_macros

- Description: Undefined preprocessor macros.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["MYMACRO"]`

#### target_flags

- Description: Toolchain-specific target-specific flags. These flags will be passed both to the compiler and linker.
- Type: Array of Strings
- Mandatory Field: Yes
- Example for a desktop target: `["-march=x86-64"]`
- Example for an ARM-Cortex-M4 target: `["-mcpu=cortex-m4", "-mthumb", "-mfloat-abi=hard", "-mfpu=fpv4-sp-d16"]`

#### asm_compiler_flags, c_compiler_flags, cpp_compiler_flags

- Description: Toolchain-specific compiler flags when compiling assembly, C, C++ source files. These flags will be passed only to the compiler.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["-std=c89", "-Wall", "-Wextra", "-Wconversion", "-pedantic"]`

#### linker_flags

- Description: Toolchain-specific linker flags. These flags will be passed only to the linker.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["-Wl,--gc-sections", "-Wl,--orphan-handling=error"]`

#### archiver_flags

- Description: Toolchain-specific archiver flags. These flags will be passed only to the archiver.
- Type: Array of Strings
- Mandatory Field: No, default value: `[]`
- Example: `[]`

#### img_file_creator_flags

- Description: Toolchain-specific image file creator flags. These flags will be passed only to the image file creator.
- Type: Array of Strings
- Mandatory Field: No, default value: `[]`
- Example: `[]`

#### ext_list_creator_flags

- Description: Toolchain-specific extended list creator flags. These flags will be passed only to the extended list creator.
- Type: Array of Strings
- Mandatory Field: No, default value: `["-S", "-x", "-C", "-d", "-l", "-r", "-t", "-w"]`
- Example (same as default, but with long flags): `["--source", "--all-headers", "--demangle", "--disassemble", "--line-numbers", "--reloc", "--syms", "--wide"]`

#### size_printer_flags

- Description: Toolchain-specific size printer flags. These flags will be passed only to the size printer.
- Type: Array of Strings
- Mandatory Field: No, default value: `[]`
- Example: `["-A"]`

### Build configuration structure methods

#### get_build_dir_artifact_path()

- Description: Returns the absolute path of the artifact file inside the build directory.
- Parameters: -
- Return type: String
- Example: `let artifact_file_path = build_config_1.get_build_dir_artifact_path();`

#### get_install_dir_artifact_path()

- Description: Returns the absolute path of the artifact file inside the install directory.
- Parameters: -
- Return type: String
- Example: `let artifact_file_path = build_config_1.get_install_dir_artifact_path();`
