# CMate Reference Manual

## Configuration file of a CMate project

The project configuration file of CMate is one and only one [rhai](https://rhai.rs/book/about/features.html) script file. This rhai script file serves the very same purpose as a CMakeLists.txt file for the CMake build system, or a meson.build file for the Meson build system. It contains information necessary for the building of the C/C++ project.

### The anatomy of a CMate project configuration file

The rhai script language uses a Rust-like syntax with dynamic typing.

#### General information about the anatomy of a CMate project configuration file

- CMate project configuration files contain a lot of file system paths. To make CMate work on every computer, it is highly recommended to enter only relative paths in the CMate project configuration file.
- Every path is relative to the containing directory of the CMate project configuration file unless stated otherwise.
- CMate works with absolute paths internally, but generates build files with relative paths.

#### Create project configuration

The input rhai script file can contain exactly one project configuration. A project configuration variable can be created by the following code.

Example:

```rust
let project_config = ProjectConfig_create();
```

This code creates a variable named `project_config` which is a structure with multiple fields. See below for the explanation of all project configuration structure fields.

#### Create build configurations

The input rhai script file can contain multiple build configurations. A build configuration variable can be created by the following code.

Example:

```rust
let build_config_1 = BuildConfig_create();
let build_config_2 = BuildConfig_create();
```

This code creates multiple variables named `build_config_1` and `build_config_2` which are structures with multiple fields. See below for the explanation of all build configuration structure fields.

#### Create a CMate project

The input rhai script file shall always end with the following code. Note, that there is no `;` at the end of the line.

Example:

```rust
Project_create(project_config, [build_config_1, build_config_2])
```

- The first parameter of `Project_create()` specifies the project configuration variable which is created by the `ProjectConfig_create()` function.
- The second parameter specifies the array of build configuration variables which are created by the `BuildConfig_create()` function. If the build configurations depend on each other, it is highly recommended to list the build configurations in dependency order.

#### Import a build configuration from another CMate project

A build configuration from another CMate project can be reused by importing it into the current project.

Example:

```rust
let imported_build_config = BuildConfig_import("path/to/another/project/rhai/script/file.rhai", "build_config_name_from_another_project");
```

- The first parameter of `BuildConfig_import()` specifies the path to the rhai script file of the other project.
- The second parameter specifies the name of the build configuration to import from that project.

After importing, the build configuration fields may be modified as needed to match the requirements of the current project.

After importing, without modifying the imported build configuration, the imported build configuration still contains the absolute paths of the other CMate project.
As a result, the artifact files generated from the imported build configuration are placed in the build directory of the other CMate project.

To place the artifact files generated from the imported build configuration to the build directory of the current CMate project, change the build directory of the imported build configuration to a directory inside the current CMate project.

Example:

```shell
C:.
|
+---ProjectDirParent
|   |   cmate_parent.rhai
|   |
|   +---BuildDirParent
|   |       artifact_parent.exe
|   |
|   \---ProjectDirChild
|       |   cmate_child.rhai
|       |
|       \---BuildDirChild
|               artifact_child.exe
```

```rust
///
/// CMate file: C:/ProjectDirParent/ProjectDirChild/cmate_child.rhai
///
let project_config     = ProjectConfig_create();
let build_config_child = BuildConfig_create();
// ...
build_config_child.build_name         = "BuildDirChild";
build_config_child.build_dir          = "BuildDirChild"; // This path is resolved internally by CMate to: C:/ProjectDirParent/ProjectDirChild/BuildDirChild
build_config_child.install_dir        = "BuildDirChild"; // This path is resolved internally by CMate to: C:/ProjectDirParent/ProjectDirChild/BuildDirChild
build_config_child.artifact_base_name = "artifact_child";
build_config_child.artifact_extension = ".exe";
build_config_child.post_build_steps   = ["./BuildDirChild/artifact_child.exe"]; // This path is resolved internally by CMate to: C:/ProjectDirParent/ProjectDirChild/BuildDirChild/artifact_child.exe
// ...
Project_create(project_config, [build_config_child])
```

```rust
///
/// CMate file: C:/ProjectDirParent/cmate_parent.rhai
///
let project_config      = ProjectConfig_create();
let build_config_parent = BuildConfig_create();
// ...
build_config_parent.build_name         = "BuildDirParent";
build_config_parent.build_dir          = "BuildDirParent"; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirParent
build_config_parent.install_dir        = "BuildDirParent"; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirParent
build_config_parent.artifact_base_name = "artifact_parent";
build_config_parent.artifact_extension = ".exe";
build_config_parent.post_build_steps   = ["./BuildDirParent/artifact_parent.exe"]; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirParent/artifact_parent.exe
// ...
let imported_build_config_child = BuildConfig_import("./ProjectDirChild/cmate_child.rhai", "BuildDirChild");
// ...
// The fields of `imported_build_config_child` can be modified here.
// ...
Project_create(project_config, [build_config_parent, imported_build_config_child])
```

Without modifying the imported build configuration, the artifact file `artifact_child.exe` is generated to the build directory of the child project (`C:/ProjectDirParent/ProjectDirChild/BuildDirChild`).

By modifying the build directory and post-build steps of the imported build configuration,

```rust
// ...
// Without modifying:
// imported_build_config_child.build_dir = "C:/ProjectDirParent/ProjectDirChild/BuildDirChild"
// ...
imported_build_config_child.build_dir        = "BuildDirChild";                        // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirChild
imported_build_config_child.install_dir      = "BuildDirChild";                        // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirChild
imported_build_config_child.post_build_steps = ["./BuildDirChild/artifact_child.exe"]; // This path is resolved internally by CMate to: C:/ProjectDirParent/BuildDirChild/artifact_child.exe
// ...
// After modifying:
// imported_build_config_child.build_dir = "C:/ProjectDirParent/BuildDirChild"
// ...
```

the artifact file `artifact_child.exe` is generated to the build directory of the parent project (`C:/ProjectDirParent/BuildDirChild`).

#### Additional CMate utility functions

- `File_write("path/to/file", "string")`: Writes `string` to `file`. Creates the file and all intermediate directories if they do not exist.

- `File_append("path/to/file", "string")`: Appends `string` to `file`. Creates the file and all intermediate directories if they do not exist.

- `let content = File_read("path/to/file")`: Reads the content of the file.

- `let date = DateShort_get()`: Returns the current date in `YYY-MM-DD` format.

- `let date = DateLong_get()`: Returns the current date in `YYY-MM-DD HH:MM:SS` format.

- `let url = GitRepoUrl_get()`: Returns the remote URL of the Git repository. In case of any errors, this function returns an empty string. Corresponds to the following command: `git remote get-url origin`.

- `let hash = GitHashShort_get()`: Returns the Git hash of the last commit in short form. In case of any errors, this function returns an empty string. Corresponds to the following command: `git rev-parse --short HEAD`.

- `let hash = GitHashFull_get()`: Returns the Git hash of the last commit in long form. In case of any errors, this function returns an empty string. Corresponds to the following command: `git rev-parse HEAD`.

- `let tag = GitTagLast_get()`: Returns the name of the last Git tag. In case of any errors, this function returns an empty string. Corresponds to the following command: `git describe --tags --abbrev=0`.

- `let tag = GitTagExact_get()`: Returns the name of the exact Git tag that points to the latest commit. In case of any errors, this function returns an empty string. Corresponds to the following command: `git describe --tags --exact-match HEAD`.

- `let result = ForegroundProcess_run("program", ["arg1", "arg2", "arg3"])`: Runs `program` (with arguments `arg1`, `arg2` and `arg3`) in the foreground (waits for the completion of the process). Returns the result as a map. The returned map has the following keys: `code`, `stdout`, `stderr`. The values of the returned map can be accessed like this: `result.code`, `result.stdout`, `result.stderr`.

- `BackgroundProcess_run("program", ["arg1", "arg2", "arg3"])`: Runs `program` (with arguments `arg1`, `arg2` and `arg3`) in the background (does not wait for the completion of the process). Before termination, CMate closes the launched background process.

- `let os = Os_get()`: Returns the current operating system as a string, `windows` or `linux`.

### Project configuration structure fields

#### project_name

- Description: The descriptive name of the project.
- Type: String
- Mandatory Field: Yes
- Examples: `"ExampleProject"`

#### ide_type

- Description: The type of Integrated Development Environment support files to generate.
- Type: String
- Mandatory Field: Yes
- Accepted Values: "None", "VSCode"
- Examples: `"None"`, `"VSCode"`

#### ide_dir

- Description: The base directory where the Integrated Development Environment support files are generated. In case of VSCode, this path shall not contain the final `.vscode` directory.
- Type: String
- Mandatory Field: Yes
- Examples: `"."`, `".."`, `"MyIdeDir"`

### Build configuration structure fields

#### General information about the build configuration structure fields

- Some fields accept [glob](https://en.wikipedia.org/wiki/Glob_(programming)#Syntax) patterns. Glob patterns can be used to specify paths with wildcards. Besides the standard glob syntax elements (`*`, `?`, `[abc]`, `[a-z]`) that are listed on the above mentioned web page, the `!` character can be used to negate a glob pattern and the `|` character can be used to allow an empty match (by default, a glob pattern is required to match at least one file or directory). The `!` and `|` characters can only occur once at the beginning of the pattern and only one of them is allowed in a pattern at the same time.
- Toolchain specific flags shall not be applied in most of the fields.
  - Do not insert the `-T` flag in the `linker_scripts` field.
  - Do not insert the `-L` flag in the `linker_search_dirs` field.
  - Do not insert the `-l` flag in the `linker_additional_libs` field.
  - Do not insert the `-I` flag in the `include_dirs` field.
  - Do not insert the `-include` flag in the `include_files` field.
  - Do not insert the `-D` flag in the `defined_preprocessor_macros` field.
  - Do not insert the `-U` flag in the `undefined_preprocessor_macros` field.
- Toolchain specific flags shall only be applied in the following fields:
  - `target_flags`, e.g. `"-march=x86-64"`
  - `compiler_flags`, e.g. `"-std=c89"`, `"-Wall"`, `"-Wextra"`, `"-Wconversion"`, `"-pedantic"`
  - `linker_flags`, e.g. `"-Wl,--gc-sections"`
  - `ext_list_creator_flags`, e.g. `"-S"`, `"-x"`, `"-C"`, `"-d"`, `"-l"`, `"-r"`, `"-t"`, `"-w"`

#### build_name

- Description: The name of the build configuration. Every build configuration shall have a unique name.
- Type: String
- Mandatory Field: Yes
- Examples: `"Debug"`, `"Release"`

#### build_dir

- Description: The directory where the build files and the artifact files are generated. Every build configuration shall have a unique build directory.
- Type: String
- Mandatory Field: Yes
- Examples: `"Debug"`, `"Release"`, `"../BuildDir"`, `"ChildDir/BuildDir"`

#### install_dir

- Description: The directory where the artifact file is copied when CMate executes the install target. The directory is created if it does not exist.
- Type: String
- Mandatory Field: Yes
- Examples: `"Install"`

#### build_type

- Description: The type of the build configuration. Whether to build an executable file or build a static library file.
- Type: String
- Mandatory Field: Yes
- Accepted Values: "Executable", "StaticLib"
- Examples: `"Executable"`, `"StaticLib"`

#### artifact_base_name

- Description: The base name of the artifact file. The artifact file is the final product of the build, an executable file or a static library file.
- Type: String
- Mandatory Field: Yes
- Examples: `"myexecutable"`, `"mylib"`

#### artifact_extension

- Description: The extension of the artifact file. The artifact file is the final product of the build, an executable file or a static library file. This field is only taken into account if the build type is executable. The artifact file will have a `lib` prefix and a `.a` extension if the build type is static library.
- Type: String
- Mandatory Field: Yes
- Examples: `".exe"`, `".elf"`, `""`

#### parallel_build_jobs

- Description: The number of parallel build jobs ninja or make will use to execute the build process.
- Type: Integer
- Mandatory Field: No, default value: number of processor cores
- Examples: `8`

#### toolchain_prefix

- Description: A string that will act as a prefix when invoking toolchain executables (compiler, linker, archiver, etc.). The toolchain executable is invoked prefixed by this value without any spaces or additional characters.
- Type: String
- Mandatory Field: Yes
- Examples: `"arm-none-eabi-"`, `""`

#### compiler_path, linker_path, archiver_path, img_file_creator_path, ext_list_creator_path, size_printer_path

- Description: The toolchain executables.
- Type: String
- Mandatory Field: Yes
- Example for Desktop GCC (in order): `"gcc"`, `"gcc"`, `"ar"`, `"objcopy"`, `"objdump"`, `"size"`
- Example for ARM32 GCC (in order): `"arm-none-eabi-gcc"`, `"arm-none-eabi-gcc"`, `"arm-none-eabi-ar"`, `"arm-none-eabi-objcopy"`, `"arm-none-eabi-objdump"`, `"arm-none-eabi-size"`
- Example for LLVM (in order): `"clang"`, `"clang"`, `"llvm-ar"`, `"llvm-objcopy"`, `"llvm-objdump"`, `"llvm-size"`

#### pre_build_steps, post_build_steps

- Description: Commands to execute before or after the build. The post-build step is only executed if the build process succeeds. The commands are executed as subprocesses. Multiple commands can be separated with the `;` character.
- Type: Array of Strings
- Mandatory Field: Yes
- Example for running the built application as post-build step: `["./Debug/program.exe"]`
- Example for running a Windows shell command as post-build step: `["cmd", "/c", "echo Build Finished"]`
- Example for running a Linux shell command as post-build step: `["sh", "-c", "echo Build Finished"]`
- Example for running multiple post-build steps: `["post", "build", "step", "1", ";", "post", "build", "step", "2", ";", "post", "build", "step", "3"]`
- Example for loading an executable file to a microcontroller with an already running OpenOCD and GDB: `["arm-none-eabi-gdb", "-q", "-ex", "set confirm off", "-ex", "target remote localhost:3333", "-ex", "monitor reset halt", "-ex", "load Debug/program.elf", "-ex", "continue", "-ex", "kill", "-ex", "quit"]`

#### dependency_build_configs

- Description: The names of the build configurations that are the dependencies of the current build configuration. Dependency build configurations will be built prior to the current build configuration. Multiple build configurations can be chained with this option. Can be useful for example when an executable file depends on a static library file.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["StaticLib"]`

#### linker_scripts

- Description: The linker scripts to use when linking the object files to an executable file.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["memregions.ld", "linker.ld"]`

#### linker_search_dirs

- Description: Additional directories where the linker will search for additional libraries.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["StaticLib"]`

#### linker_additional_libs

- Description: Additional libraries to link to the executable. Do not include the `lib` prefix and `.a` extension when specifying additional libraries, those are added automatically by the toolchain. So, if `libmylib.a` is a static library that should be linked to the executable, specify `mylib` here.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples: `[]`, `["mylib"]`

#### include_dirs

- Description: Include directories. This field accepts glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["inc"]`
- Example with glob syntax that lists all directories in the current directory non-recursively: `["*"]`
- Example with glob syntax that lists all directories in the current directory recursively: `["**"]`
- Example with glob syntax that lists all directories in the current directory recursively excluding specific directories: `["**", "!**/excluded_directory"]`

#### include_files

- Description: Header files that will be pre-included to the beginning of all source files. This field accepts glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["mypreincludedheaderfile.h"]`
- Example with glob syntax that lists all C/C++ header files in the current directory non-recursively: `["*.h", "*.hpp"]`
- Example with glob syntax that lists all C/C++ header files in the current directory recursively: `["**/*.h", "**/*.hpp"]`
- Example with glob syntax that lists all C/C++ header files in the current directory recursively excluing specific files: `["**/*.h", "**/*.hpp", "!**/excluded_c_header_file.h", "!**/excluded_cpp_header_file.hpp"]`

#### source_files

- Description: Source files. This field accepts glob patterns.
- Type: Array of Strings
- Mandatory Field: Yes
- Examples without glob syntax: `[]`, `["src/lib.c", "src/main.c"]`
- Example with glob syntax that lists all C/C++ source files in the current directory non-recursively: `["*.c", "*.cpp"]`
- Example with glob syntax that lists all C/C++ source files in the current directory recursively: `["**/*.c", "**/*.cpp"]`
- Example with glob syntax that lists all C/C++ source files in the current directory recursively excluing specific files: `["**/*.c", "**/*.cpp", "!**/excluded_c_source_file.c", "!**/excluded_cpp_source_file.cpp"]`

#### defined_preprocessor_macros

- Description: Defined preprocessor macros.
- Type: Array of Strings
- Mandatory Field: Yes
- Example without value: `["MYMACRO"]`
- Example with integer value: `["MYMACROWITHINTVALUE=42"]`
- Example with string value: `["MYMACROWITHSTRINGVALUE='Hello\r\nWorld!'"]`

#### undefined_preprocessor_macros

- Description: Undefined preprocessor macros.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["MYMACRO"]`

#### target_flags

- Description: Toolchain-specific target-specific flags. These flags will be passed both to the compiler and linker.
- Type: Array of Strings
- Mandatory Field: Yes
- Example for a desktop target: `["-march=x86-64"]`
- Example for an ARM-Cortex-M4 target: `["-mcpu=cortex-m4", "-mthumb", "-mfloat-abi=hard", "-mfpu=fpv4-sp-d16"]`

#### compiler_flags

- Description: Toolchain-specific compiler flags. These flags will be passed only to the compiler.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["-std=c89", "-Wall", "-Wextra", "-Wconversion", "-pedantic"]`

#### linker_flags

- Description: Toolchain-specific linker flags. These flags will be passed only to the linker.
- Type: Array of Strings
- Mandatory Field: Yes
- Example: `["-Wl,--gc-sections", "-Wl,--orphan-handling=error"]`

#### ext_list_creator_flags

- Description: Toolchain-specific extended list creator flags. These flags will be passed only to the extended list creator.
- Type: Array of Strings
- Mandatory Field: No, default value: `["-S", "-x", "-C", "-d", "-l", "-r", "-t", "-w"]`
- Example (same as default, but with long flags): `["--source", "--all-headers", "--demangle", "--disassemble", "--line-numbers", "--reloc", "--syms", "--wide"]`
